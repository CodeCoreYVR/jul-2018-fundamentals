document.write("This is coming from external JS!!");
